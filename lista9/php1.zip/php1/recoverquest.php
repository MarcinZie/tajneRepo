<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<meta charset="uft-8" />
	<title>Odzyskiwanie haseł</title>
</head>

<body>

	<h1> Odzyskaj hasło</h1>
	
	
	<form action="questions.php" method="post">
	
	<br/>
	Podaj imie parnera/partnerki:
	<input type="text" name="rpartner"/>
	<br/><br/>
	Podaj ulubione zwierze:
	<input type="text" name="animal"/>	
	<br/><br/>
	<input type="submit" value="Zatwierdź"/>
	</form>
	


</body>
</html>