<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<meta charset="uft-8" />
	<title>Odzyskiwanie haseł</title>
</head>

<body>

	<h1> Odzyskaj hasło</h1>
	
	
	<form action="sprawdz.php" method="post">
	
	<br/>
	Podaj login:
	<input type="text" name="rlogin"/>
	<br/><br/>
	Podaj imię:
	<input type="text" name="rimie"/>
	<br/><br/>
	Podaj nazwisko:
	<input type="text" name="rnazwisko"/>
	<br/><br/>
	Podaj nr telefonu:
	<input type="text" name="rtelefon"/>
	<br/><br/>
	Podaj email:
	<input type="text" name="remail"/>
	<br/><br/>
	<input type="submit" value="Zatwierdź"/>
	</form>
	


</body>
</html>