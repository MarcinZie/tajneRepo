<?php
	session_start();
	require_once "connect.php";
	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
	if ($polaczenie->connect_errno!=0)
	{
		echo "Error: ".$polaczenie->connect_errno;
	}
	else{
		
	$login = $_SESSION['rlogin'];
	$partner = $_POST['rpartner'];
	$animal = $_POST['animal'];
		
		
		
		$sql = "SELECT * FROM users   WHERE login='$login' AND partner='$partner' AND animal = '$animal'";
		
		$_SESSION['random'] = rand(10000000, 99999999);
		
		if($rezultat = $polaczenie->query($sql)){
			$ile_userow = $rezultat->num_rows;
			if($ile_userow>0){
				$sqlblock = "UPDATE users SET blocked=0 where login = $login";
				$polaczenie->query($sqlblock);
				echo $_SESSION['random'];
				echo "Wysłano SMSa/maila z randomowym minimum 8 cyfrowym kodem. Wpisz kod poniżej by wygenerować nowe hasło";?>
				<form action="kod.php" method="post">
	
	<br/>
	Podaj kod:
	<input type="text" name="kod"/>
	<br/><br/>
	<input type="submit" value="Zatwierdź"/>
	</form>
	<?php
			}
		}
		else{
			echo "blad".$polaczenie -> query($sql);
		}
		
	}
		
		
		$polaczenie->close();
	

	
	
	
	

?>