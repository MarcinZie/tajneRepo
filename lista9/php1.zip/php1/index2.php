<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<meta charset="uft-8" />
	<title>Logowanie</title>
</head>

<body>
	
	<h1>ZAREJESTROWANY!<br/> Zaloguj się do banku</h1>
	
	<form action="zaloguj.php" method="post">
	Login:
	<input type="text" name="login"/>
	<br/><br/>
	Hasło:
	<input type="password" name="haslo"/>
	<br/><br/>
	
	<input type="submit" value="Zaloguj"/>
	</form>
	

	

</body>
</html>