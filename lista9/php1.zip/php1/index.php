<?php 

	session_start(); 
	if (isset($_POST['haslo'])){
		
		$ok = true;
		$sekret = "6LcI8z4UAAAAALFLC2suSCuK1sKzET5Wk3XI505Z";
		$sprawdz = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$sekret.'&response='.$_POST['g-recaptcha-response']);
		
		$odpowiedz = json_decode($sprawdz);
		
		if($odpowiedz->success==false){
			$ok = false;
			$_SESSION['e_bot']="Potwierdź, że nie jesteś botem!";
		}
		
		if($ok == true){
			header('Location: zaloguj.php'); 
		}
		
	}

?>

<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<meta charset="uft-8" />
	<title>Logowanie</title>
	<script src='https://www.google.com/recaptcha/api.js'></script>
</head>

<body>


	<script TYPE="text/javascript" src="./fbapp/fb.js"></script>
	
	<?php if(isset($_SESSION['name'])) {echo $_SESSION['name'];}?>
	<?php if (isset($_SESSION['name'])) {} else{ ?>
	<div class="fb-login-button" data-scope="public_profile,email"  onlogin="checkLoginState();"></div>
		<?php } ?>
	<h1> Zaloguj się do banku</h1>
	
	<form method="post">
	Login:
	<input type="text" name="login"/>
	<br/><br/>
	Hasło:
	<input type="password" name="haslo"/>
	<br/><br/>
	<div class="g-recaptcha" data-sitekey="6LcI8z4UAAAAAHxpchQwSDt5Y2fCxXATGJ4kjYM2"></div><br/>
	<?php
			if (isset($_SESSION['e_bot']))
			{
				echo $_SESSION['e_bot'].'</div>';
				unset($_SESSION['e_bot']);
			}
		?>	
	<input type="submit" value="Zaloguj"/>
	
	
	

	</form>
	<a href="recover.php">Odzyskaj hasło</a>
	
	<h1> Zarejestruj się w banku</h1>
	<form action="zarejestruj.php" method="post">
	Nowy login:
	<input type="text" name="nowylogin"/>
	<br/><br/>
	Nowe hasło:
	<input type="password" name="nowehaslo"/>
	<br/><br/>
	
	<input type="submit" value="Zarejestruj"/>
	</form>
	

	<h1> Admin logowanie</h1>
	
	<form action="zalogujAdmin.php" method="post">
	Hasło:
	<input type="password" name="haslo"/>
	<br/><br/>
	
	
	<input type="submit" value="LogAdmin"/>
	</form>
	
	
	<a href="logout.php">Logout</a>
	
	
	
</body>
</html>