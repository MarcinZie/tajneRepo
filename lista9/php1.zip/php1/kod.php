<!DOCTYPE HTML>
<html lang = "pl">
<head>
	<meta charset="uft-8" />
	<title>Bank</title>
</head>

<body>
	<?php
	session_start();
	
	
	
	
		
	if ($_POST['kod'] == $_SESSION['random']){
		
	
	
	?>
	<form action="zmienhaslo.php" method="post">
	<br/>
	
	Podaj nowe haslo:
	<input type="text" name="newpass"/>
	<br/><br/>
	<input type="submit" value="Zatwierdź"/>
	</form>
	<?php
	}
	?>
	
		
</body>
</html>	
		

	
	
	
