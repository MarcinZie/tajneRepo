<?php
	session_start();
	require_once "connect.php";
	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
	if ($polaczenie->connect_errno!=0)
	{
		echo "Error: ".$polaczenie->connect_errno;
	}
	else
	{
		$login = $_SESSION['rlogin'];
		$haslo = $_POST['newpass'];
		
		$hasloc = password_hash($haslo.$login, PASSWORD_DEFAULT);
		
		
		
		$sql2 = "SELECT * FROM users WHERE login='$login' ";
		if($rezultat = $polaczenie->query($sql2)){
			
			$ile_userow = $rezultat->num_rows;
			if($ile_userow==1){
				$sql = "UPDATE users SET haslo=$hasloc WHERE login = $login";
				$polaczenie->query($sql);
				
				header('Location: index3.php');
				
			}else{
				echo $login." ".$haslo." ".$hasloc;
			}
			
		}
		else{
			echo $polaczenie->query($sql2);
		}
		
		
		
		
		$polaczenie->close();
	}

	
	
	
	

?>