<?php
require_once(__DIR__."/PHP/mysite.php");


$OPIS = "Strona na zaliczenie drugiego projektu";

$P =  new myPage("Drugi projekt");
$P->SetDescription($OPIS);


echo $P->Begin();
echo $P->PageHeader();
?>
<div id="omniebar">
			<img id="fotazielinskiego" src="eeee.jpg" alt="ryjzielinskiego">
			<div id="loremipsumbar">
				<div class="h2"> Drugi rok studiów.</div>
					Ciekawiej! Bazy danych, technologie programowania i wiele kursów programistycznych. Pierwsza możliwość zadecydowania o kursie wybieralnym i nadal sporo matematyki, grafy i takie tam. Doświadczenie z sieciami, a także algorytmy i struktury danych i spotkanie z Assemblerem. Dużo wspomnień i więcej pracy!
				</div>
		
		</div>
		<div id="semestrybar">
		
			<div class="semestr">
				<div class="h1"> III</div>
				
				<ul class="lista-zajec">
					<li>AKiSO</li>
					<li>Technologie programowania</li>
					<li>Grafy</li>
					<li>Logika</li>
				</ul>
			</div>
			<div class="semestr">
				<div class="h1"> IV</div>
				<ul class="lista-zajec">
					<li>AIDS</li>
					<li>Topologia</li>
					<li>Programowanie</li>
					<li>Angielski</li>
				</ul>			
			</div>
			
		
		</div>	


<?php
 
echo $P->End();

?>