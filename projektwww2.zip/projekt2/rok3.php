<?php
require_once(__DIR__."/PHP/mysite.php");


$OPIS = "Strona na zaliczenie drugiego projektu";


$P =  new myPage("Drugi projekt");
$P->SetDescription($OPIS);


echo $P->Begin();
echo $P->PageHeader();
?>
<div id="omniebar">
			<img id="fotazielinskiego" src="ffff.jpg" alt="ryjzielinskiego">
			<div id="loremipsumbar">
				<div class="h2"> Trzeci rok studiów.</div>
				Zabawa się rozpoczyna! Kompilator w połączeniu z trudnymi wybieralnymi to wybuchowa mieszanka! Obliczenia naukowe i Julia oraz bardzo ciekawe przedmioty dr Zagórskiego pokazały że informatyka jest bardzo trudną dziedziną, ale również wyzwaniem i możliwością rozwijania się w różnorakich sposobach rozumowania. Tak samo logika w informatyce na VI semestrze, zmusza nas do myślenia rekurencyjnego. 
			</div>
		
		</div>
		<div id="semestrybar">
		
			<div class="semestr">
				<div class="h1"> V</div>
				
				<ul class="lista-zajec">
					<li>Topologia</li>
					<li>Bezpieczeństwo</li>
					<li>Obliczenia</li>
					<li>Kompilatory</li>
				</ul>
			</div>
			<div class="semestr">
				<div class="h1"> VI</div>
				<ul class="lista-zajec">
					<li>Internety</li>
					<li>Logika</li>
					<li>Wbudowane</li>
					<li>Zespolone</li>
				</ul>
			
			
			</div>
			
		
		</div>	


<?php

echo $P->End();

?>