<?php
require_once(__DIR__."/PHP/mysite.php");


$OPIS = "Strona na zaliczenie drugiego projektu";


$P =  new myPage("Drugi projekt");
$P->SetDescription($OPIS);


// Wyświetlamy początek strony
echo $P->Begin();
echo $P->PageHeader();
?>
<div style="text-align: center;">
		<h1>Skontaktujmy się!</h1>
		<h4>Nr telefonu: 693 733 937</h4>
		<h4>E-mail: 229810@student.pwr.edu.pl</h4>
		</div>


<?php

echo $P->End();

?>