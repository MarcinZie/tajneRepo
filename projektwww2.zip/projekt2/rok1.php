<?php
require_once(__DIR__."/PHP/mysite.php");


$OPIS = "Strona na zaliczenie drugiego projektu";


$P =  new myPage("Drugi projekt");
$P->SetDescription($OPIS);


echo $P->Begin();
echo $P->PageHeader();
?>

		<div id="omniebar">
			<img id="fotazielinskiego" src="kkkk.jpg" alt="ryjzielinskiego">
			<div id="loremipsumbar">
				<div class="h2"> Pierwszy rok studiów.</div>
				Pierwsze dwa semestry minęły w błogiej radości i nieświadomości zbliżającego się zagrożenia ze strony bizona i flexa. Był to czas matematyki i nauki czytania skomplikowanych znaczków, kwantyfikatorów i innych dziwactw. W tym czasie postawiliśmy pierwsze kroki w programowaniu strukturalnym jak i obiektowym (to na drugim semestrze), by na kolejnych semestrach móc rozbudowywać solidne podstawy o kolejne mechanizmy informatyki. Radość czerpana z poznawiania uczelni była świetnym czasem.
			</div>
		
		</div>
		<div id="semestrybar">
		
			<div class="semestr">
				<div class="h1"> I</div>
				
				<ul class="lista-zajec">
					<li>Analiza</li>
					<li>Algebra</li>
					<li>Wstęp</li>
					<li>Logika</li>
				</ul>
			</div>
			<div class="semestr">
				<div class="h1"> II</div>
				<ul class="lista-zajec">
					<li>Analiza II</li>
					<li>Algebra II</li>
					<li>Programowanie</li>
					<li>Angielski</li>
				</ul>
			
			
			</div>
			
		
		</div>	


<?php

echo $P->End();

?>