<?php

$HEADER =<<<EOT
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <title>{{TITLE}}</title> 
  <meta name="description" content= "{{DESCRIPTION}}">
  <meta name="author" content="Marcin Zieliński">
  <meta name="viewport" content = "width=device-width, initial-scale=1.0"/>
{{STYLES}}
{{SCRIPTS}}
{{INNER-STYLE}}
</head>
<body>
<div id="container">
EOT;

$PAGE_HEADER =<<<EOT
<div id="menubar">
			<div class="col-2">
				<a href=mysite.php><img id="menubarlogo" src=logo.png alt="logotyp "></a> 
			</div>
			<div class="col-8">
				<div id="menubarmenu">
					<div class="menubaritem"><a href=mysite.php>Strona główna</a></div>
					<div class="menubaritem"><a href=rok1.php>Rok 1</a></div>
					<div class="menubaritem"><a href=rok2.php>Rok 2</a></div>
					<div class="menubaritem"><a href=rok3.php>Rok 3</a></div>
					<div class="menubaritem" style="border-right:0;"><a href=kontakt.php>Kontakt</a></div>
				</div>
			</div>
</div>
	
EOT;

$FOOTER =<<<EOT
<div id="footer">
			Copyright mocno 2k18
	</div>
</div><!-- container -->
</body>
</html>   
EOT;

/**
* Klasa sluzaca do generowania stron ustalonej witryny
* @package myPage
* @author Jacek Cichon
*/
class MyPage {
  private $title        = "";
  private $description  = "";
  private $root         = "";
  private $cssfiles     = [];
  private $jsfiles      = [];
  private $innerStyle   = "";

  public function AddCSS($filename) {
    $this->cssfiles[] = $filename;
  }

 
  public function AddJS($filename) {
    $this->jsfiles[] = $filename;
  }
  
  
  public function SetDescription($s) {
    $this->description = $s;
  }

  public function AddInnerStyle($s) {
    $this->innerStyle = $s;
  }
  
  
  public function __construct($title = "", $root="") {
    $this->title = $title;
    $this->root  = $root;
    $this->AddCSS("reset.css");
    $this->AddCSS("grid.css");
    $this->AddCSS("indexstyle.css");
  }

  public function Begin() {
    global $HEADER;
    $s = str_replace(["{{TITLE}}", "{{DESCRIPTION}}"], [$this->title, $this->description], $HEADER);
    
   
    $X = [];
    $C = $this->cssfiles;
    $TMP = '  <link rel="stylesheet" href="{{R}}css/{{CSS}}">' . "\n";
    for ($i = 0; $i < count($C); $i++){
      $X[]= (string) str_replace(["{{R}}", "{{CSS}}"], [$this->root, (string) $C[$i]], $TMP);
    } 
    $s= str_replace("{{STYLES}}", join("\n",$X), $s);
    
  
    $X = [];
    $C = $this->jsfiles;
    $T = '  <script src="{{R}}js/{{JS}}"></script>' . "\n";
    for ($i = 0; $i < count($this->jsfiles); $i++){
      $X[]= str_replace(["{{R}}", "{{JS}}"], [$this->root, (string) $C[$i]], $T);
    } 
    $s= str_replace("{{SCRIPTS}}", join("\n",$X), $s);
 
    $X = ($this->innerStyle === "") ? "" : "<style>\n" . $this->innerStyle . "\n</style>\n"; 
    $s= str_replace("{{INNER-STYLE}}", $X, $s);
    

    return preg_replace('/^\h*\v+/m', '', $s);
    
  }

  public function PageHeader(){
    global $PAGE_HEADER;
    return $PAGE_HEADER;
  }
   
  public function End() {
    global $FOOTER;
    return $FOOTER;    
  }  

} 

?>