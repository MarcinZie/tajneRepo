<?php
require_once(__DIR__."/PHP/mysite.php");


$OPIS = "Strona na zaliczenie drugiego projektu";



$P =  new myPage("Drugi projekt");
$P->SetDescription($OPIS);



echo $P->Begin();
echo $P->PageHeader();
?>
<div id="omniebar">
			<img id="fotazielinskiego" src="ja.jpg" alt="ryjzielinskiego">
			<div id="loremipsumbar">
				<div class="h2">O mnie</div>
				Lorem Ipsum jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetuum.
			</div>
		
		</div>
		<div id="opisybar">
		
			<div class="opis"><p>Memy!</p><p><img class="fotawramce" src="aaaa.jpg" alt="clown"></p></div>
			<div class="opis"><p>Fotografia!</p><p><img class="fotawramce" src="bbbb.jpg" alt="kubek"></p></div>
			<div class="opis"><p>Studia</p><p><img class="fotawramce" src="cccc.jpg" alt="C-7"></p></div>
			
		
		</div>	


<?php

echo $P->End();

?>